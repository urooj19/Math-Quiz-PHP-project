<?php
$con= new mysqli('localhost','admingst','getsolutry','getsolutry_db');; /*or die("Could not connect to mysql".mysqli_error($con));*/
?>